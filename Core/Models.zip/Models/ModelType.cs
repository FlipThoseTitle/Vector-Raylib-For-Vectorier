﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vector.Core.Models
{
    public enum ModelType
    {
        None,
        Human,
        Primitive,
        PrimitiveAnimated
    }
}
